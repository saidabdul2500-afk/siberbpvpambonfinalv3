import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Log all API requests
app.use('/api', (req, res, next) => {
  console.log(`[API] ${req.method} ${req.url}`);
  next();
});

// API Route for Google Sheets Sync
app.get('/api/users', async (req, res) => {
  const scriptUrl = (process.env.APPS_SCRIPT_URL || '').trim();
  if (!scriptUrl) {
    console.error('[API] APPS_SCRIPT_URL not set');
    return res.status(500).json({ error: 'APPS_SCRIPT_URL not set in environment variables' });
  }
  
  if (!scriptUrl.startsWith('http')) {
    console.error('[API] Invalid APPS_SCRIPT_URL (must start with http):', scriptUrl);
    return res.status(500).json({ error: 'APPS_SCRIPT_URL harus berupa URL lengkap (dimulai dengan https://)' });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // Increased to 30s
    console.log(`[API] Fetching users from: ${scriptUrl}`);
    const response = await fetch(`${scriptUrl}?action=getUsers`, { 
      signal: controller.signal,
      headers: { 'Accept': 'application/json' }
    });
    clearTimeout(timeout);
    
    if (!response.ok) {
      throw new Error(`Apps Script returned status ${response.status}`);
    }

    const text = await response.text();
    try {
      const data = JSON.parse(text);
      res.json(data);
    } catch (e) {
      console.error('Apps Script returned non-JSON for getUsers:', text.substring(0, 500));
      res.status(500).json({ error: 'Apps Script returned invalid JSON', details: text.substring(0, 100) });
    }
  } catch (error: any) {
    console.error('[API] Error fetching users:', error.message);
    res.status(500).json({ error: `Fetch failed: ${error.message}` });
  }
});

app.get('/api/requests', async (req, res) => {
  const scriptUrl = (process.env.APPS_SCRIPT_URL || '').trim();
  if (!scriptUrl) {
    console.error('[API] APPS_SCRIPT_URL not set');
    return res.status(500).json({ error: 'APPS_SCRIPT_URL not set in environment variables' });
  }

  if (!scriptUrl.startsWith('http')) {
    console.error('[API] Invalid APPS_SCRIPT_URL (must start with http):', scriptUrl);
    return res.status(500).json({ error: 'APPS_SCRIPT_URL harus berupa URL lengkap (dimulai dengan https://)' });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000); // Increased to 30s
    console.log(`[API] Fetching requests from: ${scriptUrl}`);
    const response = await fetch(`${scriptUrl}?action=getRequests`, { 
      signal: controller.signal,
      headers: { 'Accept': 'application/json' }
    });
    clearTimeout(timeout);

    if (!response.ok) {
      throw new Error(`Apps Script returned status ${response.status}`);
    }

    const text = await response.text();
    try {
      const data = JSON.parse(text);
      res.json(data);
    } catch (e) {
      console.error('Apps Script returned non-JSON for getRequests:', text.substring(0, 500));
      res.status(500).json({ error: 'Apps Script returned invalid JSON', details: text.substring(0, 100) });
    }
  } catch (error: any) {
    console.error('[API] Error fetching requests:', error.message);
    res.status(500).json({ error: `Fetch failed: ${error.message}` });
  }
});

app.post('/api/sync-sheets', async (req, res) => {
  const { requests } = req.body;
  const scriptUrl = (process.env.APPS_SCRIPT_URL || '').trim();

  if (!scriptUrl) {
    return res.status(500).json({ error: 'Konfigurasi APPS_SCRIPT_URL belum diatur di menu Secrets.' });
  }

  try {
    console.log('Syncing to Apps Script:', scriptUrl);
    
    const response = await fetch(scriptUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ requests }),
    });

    const result = await response.json();
    
    if (result.result === 'success') {
      res.json({ success: true, message: 'Data berhasil disinkronkan ke Google Sheets via Apps Script' });
    } else {
      throw new Error(result.error || 'Gagal sinkronisasi via Apps Script');
    }
  } catch (error: any) {
    console.error('Error syncing to Apps Script:', error);
    res.status(500).json({ error: `Gagal sinkronisasi: ${error.message}` });
  }
});

app.post('/api/sync-single', async (req, res) => {
  const { action, request } = req.body;
  const scriptUrl = (process.env.APPS_SCRIPT_URL || '').trim();

  if (!scriptUrl) {
    return res.status(500).json({ error: 'Konfigurasi APPS_SCRIPT_URL belum diatur.' });
  }

  try {
    console.log(`[API] Syncing single ${action} to: ${scriptUrl}`);
    const response = await fetch(scriptUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, request }),
    });

    const result = await response.json();
    if (result.result === 'success') {
      res.json({ success: true });
    } else {
      throw new Error(result.error || 'Gagal sinkronisasi via Apps Script');
    }
  } catch (error: any) {
    console.error('Sync error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/delete', async (req, res) => {
  const { action, id, role } = req.body;
  const scriptUrl = (process.env.APPS_SCRIPT_URL || '').trim();

  if (!scriptUrl) {
    return res.status(500).json({ error: 'Konfigurasi APPS_SCRIPT_URL belum diatur.' });
  }

  try {
    console.log(`[API] Deleting id ${id} from: ${scriptUrl}`);
    const response = await fetch(scriptUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, id, role }),
    });

    const result = await response.json();
    if (result.result === 'success') {
      res.json({ success: true });
    } else {
      throw new Error(result.error || 'Gagal menghapus data via Apps Script');
    }
  } catch (error: any) {
    console.error('Delete error:', error);
    res.status(500).json({ error: error.message });
  }
});

async function setupVite() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }
}

async function startServer() {
  const PORT = 3000;
  await setupVite();

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

export default app;
